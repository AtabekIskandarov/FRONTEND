// let x = 2 + 2 + '1';
// alert(x);
var advertise = {reklama: 'I wan to sell my car on www.auto.ru, here are the charateristics of my car'};
console.log (advertise.reklama);
  
var car = {
    Model: 'Audi',
    Engine: 1.8, 
    Run: '30Km', 
    Body: 'Sedan',
    Color: 'White',
    Transmission: 'Automatic',
    SteeringWheel: 'Left hand drive',
    Owners: 1,
    Condition: 'Does not need to repair'
};

console.log (car.Model);
console.log (car.Run);
console.log (car.Engine);
console.log (car.Body);
console.log (car.Color);
console.log (car.Transmission);