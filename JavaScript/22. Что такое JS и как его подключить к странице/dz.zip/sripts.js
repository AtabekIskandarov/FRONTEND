alert ("my first JS programm");

console.log ("Am I doing right?");