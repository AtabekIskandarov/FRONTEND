let now = 2021;
let iwasborn = 1983;
let my_age;

my_age = now-iwasborn; 

console.log(my_age);


let name_ = "Atabek";
let surname_ = "Iskandarov";
console.log (name_, surname_);


